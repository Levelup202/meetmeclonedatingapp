# 
<h1 align="center">MeetMe Clone</h1>

## App Screenshots

<table>
  <tr>
    <td><img src="https://mms.businesswire.com/media/20150608005455/en/471339/5/jc_app2_512.jpg" width="200"/></td>
    <td><img src="https://i.postimg.cc/VvwHZsTv/Screenshot-2021-05-18-19-25-46-424-com-example-meetme.jpg" width="200"/></td>
    <td><img src="https://i.postimg.cc/Qt3bh4qn/Screenshot-2021-05-18-19-26-03-662-com-example-meetme.jpg" width="200"/></td>
    <td><img src="https://i.postimg.cc/zXcFVXjh/Screenshot-2021-05-18-19-26-28-712-com-example-meetme.jpg" width="200"/></td>
  </tr>  
  
  <tr>
    <td><img src="https://i.postimg.cc/x1mM8Gqr/Screenshot-2021-05-18-19-26-45-774-com-example-meetme.jpg"   width="200"/></td>
    <td><img src="https://i.postimg.cc/ZR5W86Y5/Screenshot-2021-05-18-19-26-50-437-com-example-meetme.jpg"  width="200"/></td>
    <td><img src="https://i.postimg.cc/MK2j4Mdd/Screenshot-2021-05-18-19-27-17-053-com-example-meetme.jpg"  width="200"/></td>
    <td><img src="https://i.postimg.cc/QCpVsm0S/Screenshot-2021-05-18-19-27-34-414-com-example-meetme.jpg"  width="200"/></td>
  </tr>
 
 </table>


This project is designed only for learning purpose with the guidance of Masai School mentors.

This Project is made in Java with Android Studio IDE.

Dependencies Used :
- [Circular View](https://github.com/hdodenhof/CircleImageView) 
- [Glide](https://github.com/bumptech/glide) 
- All Random images available on Internet ( if any Images and Icon is not credited please email me and i will make sure to give you credit thank you :) Email prabinkumarsahu28@gmail.com )

Team Members 
- Prabin Kumar Sahu
- Sibtain Ahmad
- Aman Kumar
